export const shipment_mock = {
  carrier: "test",
  reference: "test",
  shipment: "test",
  status: "false ",
  arivalTime:"test",
};
