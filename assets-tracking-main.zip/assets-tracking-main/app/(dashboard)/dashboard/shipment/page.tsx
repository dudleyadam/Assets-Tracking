import ShipmentComponent from "@/components/ShipmentComponent";
import { getAllSeaRatesContainer } from "@/services/searates";

const page = async () => {
  return <ShipmentComponent />;
};
export default page;
